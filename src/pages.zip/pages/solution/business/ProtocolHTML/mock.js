export default {
    mod: 'protocolHTML',
    title: '方案简介',
    content: '建行云根据不同的网站规模需求提供'
}