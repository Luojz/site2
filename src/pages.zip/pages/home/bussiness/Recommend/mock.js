export default {
    title: '我们的推荐',
    desc: '建行云产品系列，祝你上云无忧，轻松运行',
    list: [
        { title: '云服务器', imgUrl: '//yun.ccb.com/common/images/recommend_products1.png', link: '//yun.ccb.com/product/cvm' },
        { title: '弹性负载均衡', imgUrl: '//yun.ccb.com/common/images/recommend_products2.png', link: '//yun.ccb.com/product/elb' },
        { title: '龙卫士', imgUrl: '//yun.ccb.com/common/images/recommend_products3.png', link: '//yun.ccb.com/product/producthids' },
        { title: 'MPP云数据', imgUrl: '//yun.ccb.com/common/images/recommend_products4.png', link: '//yun.ccb.com/product/productmpp' }
    ],
    count: 2
}