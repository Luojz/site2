export default {
    title: '合规认证',
    desc: '建设安全可靠的云生态环境，提供值得依赖的优质云服务',
    list: [
        { src: "https://yun.ccb.com/myNatural/img/iso20000_v2.png", desc: "iso2000", link: '#' },
        { src: "https://yun.ccb.com/myNatural/img/iso20000_v2.png", desc: "iso2000", link: '#' },
        { src: "https://yun.ccb.com/myNatural/img/iso20000_v2.png", desc: "iso2000", link: '#' },
        { src: "https://yun.ccb.com/myNatural/img/iso20000_v2.png", desc: "iso2000", link: '#' },
    ],
    count: 4,
}