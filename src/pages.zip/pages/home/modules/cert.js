export default {
    list:[
        {
            title:"ISO 20000",
            iconUrl:"//yun.ccb.com/myNatural/img/iso20000_v2.png"
	    },{
            title:"可信云",
            iconUrl:"//yun.ccb.com/myNatural/img/可信云.png"
        },{
            title:"ISO 27001",
            iconUrl:"//yun.ccb.com/myNatural/img/iso27001_v2.png"
        },{
            title:"网络安全等级保护",
            iconUrl:"//yun.ccb.com/myNatural/img/DJCP.png"
        }
	],
    title: '合规认证',
    desc: '建设安全可靠的云生态环境，提供值得依赖的优质云服务',
    theme:"Certification"
}