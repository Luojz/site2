export default {
    ident({ type, value }) {
        switch (type) {
            case '':
                break
            default:
                ''
        }
    },
}