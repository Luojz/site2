export default {
		"title":"云服务器",
		"subTitle":"稳定、安全、弹性、高性能的云端计算服务，实时满足多样性业务需求",
		"imgUrl":"//imagecachexxfb.yun.ccb.com/static/product/product_banner.jpg",
		"btnIcon":"buy",
		"btnTitle":"点击继续",
		"btnLink":"//console.yun.ccb.com/cvm/index",
		"addonButtons":[{
				"btnTitle":"帮助文档",
				"btnLink":"//doc.yun.ccb.com/tcloud/Compute/CloudServer"
		},{
				"btnTitle":"",
				"btnLink":""
		}]

}