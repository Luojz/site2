export default {
    "title": "产品特性",
    "list":[
        {
            "title":"多样化配置",
            "desc":{
                "blocks":[
                    {"text":"提供类型丰富的实例类型、操作系统版本和软件包；"},
                    {"text":"CPU、内存、硬盘和带宽均可灵活调整，随时升降配置。"}
                ]
            },
            iconUrl:""
        }]
}