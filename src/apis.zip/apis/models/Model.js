// export default class Model {
//     constructor(keyVals = {id: Math.random(), createdAt: Date.now(), modifiedAt: Date.now()}) {
//         Object.entries(keyVals).forEach(([key, val]) => this[key] = val)
//     }
// }

export default {
    id: Math.random(),
    createdAt: Date.now(),
    modifiedAt: Date.now()
};
