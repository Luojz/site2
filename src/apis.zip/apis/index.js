import Account from './models/Account'


const accounts = []


const respond = (Model, list) => ({ method = 'get', params }) => {
    const res = {
        statusCode: 200,
        errMsg: '',
        data: list
    }

    const h = (handle, params) => Array.isArray(params) ? params.map(handle) : handle(params)

    switch (method) {
        case 'post':
            h(params => list.push({...Model, ...params}), params)
            break
        case 'delete':
            h(params => list = list.fliter(item => item.id != params.id), params)
            break
        case 'put':
            h(params => list = list.map(item => item.id == params.id ? {...Model, ...params, modifiedAt: Date.now()} : item), params)
            break
        case 'patch':
            h(params => list = list.map(item => item.id == params.id ? {...item, ...params, modifiedAt: Date.now()} : item), params)
            break
        default:
            if (params) {
                res.data = h(params => list.find(item => Object.keys(params).every(key => item[key] === params[key])), params)
            }
    }

    return Promise.resolve(res)
}


export default {
    ACCOUNT: respond(Account, accounts)
}